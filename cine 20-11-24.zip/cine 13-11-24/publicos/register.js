

// Función para verificar la validez de la contraseña
/*
// Ejemplo de uso:
const contrasena = "Ejemplo123";
const resultado = validarContrasena(contrasena);
console.log(resultado); // Muestra si la contraseña es válida o no
*/